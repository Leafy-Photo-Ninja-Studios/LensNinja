
# AUDIT_CHECKLIST

## 1) README & Onboarding
- [x] Purpose & overview
- [x] One-command demo (`make demo`)
- [x] Sample data included
- [ ] Architecture diagram
- [ ] Screenshots / GIF demo

## 2) Codebase Hygiene
- [x] Cohesive modules (`filtering.py`, `models.py`)
- [x] Type-safe data model scaffold (Pydantic)
- [x] No leftover POC folders
- [ ] Type checks (mypy) wired in CI

## 3) Tests & CI
- [x] Sanity assertions in demo runner
- [x] GitHub Actions workflow
- [ ] Unit tests via pytest proper
- [ ] Coverage report

## 4) Security & Secrets
- [x] No secrets in repo
- [ ] Dependabot

## 5) Data & Scrapers
- [x] Normalized schema (fixture)
- [ ] Real spiders + rate limiting
- [ ] Source adapters under `providers/`

## 6) Packaging & Releases
- [x] Dockerfile scaffold
- [ ] Versioning plan & CHANGELOG

## 7) DX & Docs
- [x] Makefile (demo/test)
- [ ] CONTRIBUTING.md, templates
