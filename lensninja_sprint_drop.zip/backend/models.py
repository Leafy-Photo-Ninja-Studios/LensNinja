
from pydantic import BaseModel, HttpUrl, Field
from typing import Optional
from datetime import datetime

class LensItem(BaseModel):
    id: str
    title: str
    price: float
    currency: str = "USD"
    condition: Optional[str] = None
    brand: Optional[str] = None
    mount: Optional[str] = None
    category: Optional[str] = None
    source: str
    url: Optional[HttpUrl] = None
    scraped_at: datetime = Field(default_factory=datetime.utcnow)
    verified_image: bool = False
