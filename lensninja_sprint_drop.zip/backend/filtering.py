
from __future__ import annotations
from typing import List, Optional, Tuple, Dict, Any
from datetime import datetime

def _lc(x: Optional[str]) -> str:
    return (x or "").lower()

def filter_items(
    items: List[dict],
    query: Optional[str] = None,
    condition: Optional[str] = None,
    brand: Optional[str] = None,
    mount: Optional[str] = None,
    source: Optional[str] = None,
    price_min: Optional[float] = None,
    price_max: Optional[float] = None,
) -> List[dict]:
    """Filter a list of lens items by multiple criteria."""
    q = _lc(query)
    cond = _lc(condition)
    br = _lc(brand)
    mo = _lc(mount)
    so = _lc(source)

    def ok(item: dict) -> bool:
        if q and q not in _lc(item.get("title")):
            return False
        if cond and _lc(item.get("condition")) != cond:
            return False
        if br and br != _lc(item.get("brand")):
            return False
        if mo and mo != _lc(item.get("mount")):
            return False
        if so and so != _lc(item.get("source")):
            return False
        p = float(item.get("price", 0) or 0)
        if price_min is not None and p < price_min:
            return False
        if price_max is not None and p > price_max:
            return False
        return True

    return [it for it in items if ok(it)]

def sort_items(items: List[dict], sort_by: str = "price", order: str = "asc") -> List[dict]:
    reverse = (order.lower() == "desc")
    key = sort_by.lower()
    if key == "price":
        return sorted(items, key=lambda x: float(x.get("price", 0) or 0), reverse=reverse)
    if key == "title":
        return sorted(items, key=lambda x: (x.get("title") or "").lower(), reverse=reverse)
    if key in ("scraped_at", "date"):
        def parse_dt(s):
            try:
                return datetime.fromisoformat((s or "").replace("Z","+00:00"))
            except Exception:
                return datetime.min
        return sorted(items, key=lambda x: parse_dt(x.get("scraped_at")), reverse=reverse)
    return items

def paginate(items: List[dict], page: int = 1, page_size: int = 20) -> Tuple[List[dict], int, int]:
    page = max(1, int(page or 1))
    page_size = max(1, min(100, int(page_size or 20)))
    total = len(items)
    pages = (total + page_size - 1) // page_size
    start = (page - 1) * page_size
    end = start + page_size
    return items[start:end], total, pages

def facets(items: List[dict], fields: Optional[List[str]] = None) -> Dict[str, Dict[str, int]]:
    fields = fields or ["brand", "mount", "source", "condition", "category"]
    out: Dict[str, Dict[str, int]] = {}
    for f in fields:
        counts: Dict[str, int] = {}
        for it in items:
            v = it.get(f)
            if v is None:
                continue
            counts[str(v)] = counts.get(str(v), 0) + 1
        out[f] = dict(sorted(counts.items(), key=lambda kv: (-kv[1], kv[0])))
    return out

def price_bands(items: List[dict]) -> Dict[str, int]:
    """Simple fixed price bands; tune later or compute quantiles."""
    bands = {"<50":0, "50-100":0, "100-200":0, "200-500":0, "500+":0}
    for it in items:
        p = float(it.get("price", 0) or 0)
        if p < 50: bands["<50"] += 1
        elif p < 100: bands["50-100"] += 1
        elif p < 200: bands["100-200"] += 1
        elif p < 500: bands["200-500"] += 1
        else: bands["500+"] += 1
    return bands
