
from fastapi import FastAPI, Query
from fastapi.middleware.cors import CORSMiddleware
from typing import List, Optional
from models import LensItem
from filtering import filter_items, sort_items, paginate, facets, price_bands
import os, json

app = FastAPI(title="LensNinja API", version="0.2.0", description="FastAPI backend for LensNinja")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # TODO: lock down in prod
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

DATA_PATH = os.path.join(os.path.dirname(__file__), "data", "scraped_json", "sample_data.json")

def load_items() -> list:
    with open(DATA_PATH, "r", encoding="utf-8") as f:
        return json.load(f)

@app.get("/")
def root():
    return {"message": "LensNinja backend is live!"}

@app.get("/search", response_model=dict)
def search(
    query: Optional[str] = Query(None),
    condition: Optional[str] = Query(None),
    brand: Optional[str] = Query(None),
    mount: Optional[str] = Query(None),
    source: Optional[str] = Query(None),
    price_min: Optional[float] = Query(None),
    price_max: Optional[float] = Query(None),
    sort_by: Optional[str] = Query("price"),
    order: Optional[str] = Query("asc"),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
):
    items = load_items()
    filtered = filter_items(items, query, condition, brand, mount, source, price_min, price_max)
    sorted_items = sort_items(filtered, sort_by, order)
    page_items, total, pages = paginate(sorted_items, page, page_size)
    return {
        "results": page_items,
        "total": total,
        "pages": pages,
        "page": page,
        "page_size": page_size,
        "facets": facets(filtered),
        "bands": price_bands(filtered),
    }
