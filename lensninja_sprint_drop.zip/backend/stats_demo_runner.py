
import json, os
from filtering import filter_items, sort_items, paginate, facets, price_bands

DATA_PATH = os.path.join(os.path.dirname(__file__), "data", "scraped_json", "sample_data.json")

with open(DATA_PATH, "r", encoding="utf-8") as f:
    items = json.load(f)

# 1) Filter: Canon EF mount under $250
filtered = filter_items(items, mount="Canon EF", price_max=250)
# 2) Sort by price desc
sorted_items = sort_items(filtered, sort_by="price", order="desc")
# 3) Paginate page 1, size 3
page_items, total, pages = paginate(sorted_items, page=1, page_size=3)
# 4) Facets and price bands on the filtered set
facet_counts = facets(filtered)
bands = price_bands(filtered)

print("=== TEST RUN: LensNinja filtering/stats ===")
print(f"Total items loaded: {len(items)}")
print(f"Filtered (mount='Canon EF', price<=250): {len(filtered)} items")
print("Top 3 (by price desc):")
for it in page_items:
    print(f" - {it['title']}  ${it['price']}  [{it['condition']}]  <{it['source']}>")
print(f"Pagination: total={total}, pages={pages}")
print("Facets (top counts):", {k:list(v.items())[:3] for k,v in facet_counts.items()})
print("Price bands:", bands)

# Sanity checks (simple asserts)
assert len(items) >= 5, "Fixture too small"
assert all(it["price"] <= 250 for it in filtered), "Price filter failed"
assert page_items[0]["price"] >= page_items[-1]["price"], "Sort desc failed"
print("Assertions: PASS")
